import java.util.UUID;


public class Helper {
	public static String getUUID(){
		return UUID.randomUUID().toString();
	}
}
